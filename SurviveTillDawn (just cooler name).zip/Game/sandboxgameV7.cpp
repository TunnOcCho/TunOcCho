#include "raylib.h"
#include <cmath> // Để dùng hàm sinf, cosf

// ============================================================================
// CÁC HẰNG SỐ HỆ THỐNG VÀ KÍCH THƯỚC VẬT LÝ
// ============================================================================
const int MAP_WIDTH = 200;  
const int MAP_HEIGHT = 250; 
const int TILE_SIZE = 32;  
const int MAX_DROPPED_ITEMS = 128; 
const int INVENTORY_SIZE = 12;

const float PLAYER_COLL_WIDTH = 22.0f;  
const float PLAYER_COLL_HEIGHT = 32.0f; 

enum GameScreen {
    MENU = 0,
    GAMEPLAY = 1
};

struct GameTextures {
    Texture2D dirt;
    Texture2D grass; 
    Texture2D stone;
    Texture2D bedrock;
    Texture2D player;
    Texture2D sun;
    Texture2D cloud1;
    Texture2D cloud2;
    Texture2D cloud3;
    Texture2D moon;
};

enum BlockType {
    AIR = 0,
    DIRT = 1,
    GRASS = 2,
    STONE = 3,
    WOOD = 4,
    BEDROCK = 5 
};

struct InventorySlot {
    BlockType type;
    int count;
};

struct DroppedItem {
    Vector2 position;
    BlockType type;
    bool active;
    float velocityY;
};

int Clamp(int value, int min, int max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

// Thêm tham số gameTime và survivedDays để reset khi bấm Play
void ResetGame(float &playerX, float &playerY, float &velocityY, int worldMap[MAP_HEIGHT][MAP_WIDTH], 
               InventorySlot inventory[], DroppedItem droppedItems[], float &gameTime, int &survivedDays) {
    
    playerX = 150.0f;
    playerY = 100.0f;
    velocityY = 0.0f;

    // Reset thời gian
    gameTime = 0.0f;
    survivedDays = 0;

    for (int i = 0; i < INVENTORY_SIZE; i++) {
        inventory[i].type = AIR;
        inventory[i].count = 0;
    }
    inventory[0] = (InventorySlot){ DIRT, 10 }; 
    inventory[1] = (InventorySlot){ STONE, 10 };

    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        droppedItems[i].active = false;
    }

    float seed = (float)GetRandomValue(0, 10000); 
    
    for (int x = 0; x < MAP_WIDTH; x++) {
        int surfaceHeight = 25 + (int)(sinf((x + seed) * 0.1f) * 6.0f) + (int)(sinf((x + seed) * 0.05f) * 4.0f); 
        surfaceHeight = Clamp(surfaceHeight, 10, MAP_HEIGHT - 10);

        for (int y = 0; y < MAP_HEIGHT; y++) {
            if (y > surfaceHeight) {
                if (y > surfaceHeight + 12) worldMap[y][x] = STONE; 
                else worldMap[y][x] = DIRT;
            } 
            else if (y == surfaceHeight) {
                worldMap[y][x] = GRASS;
            }
            else {
                worldMap[y][x] = AIR;
            }
            if (y == MAP_HEIGHT - 1) worldMap[y][x] = BEDROCK;
        }
    }
}

// ============================================================================
// CÁC HÀM CẬP NHẬT LOGIC GAME
// ============================================================================

void UpdatePlayer(float &playerX, float &playerY, float &velocityY, bool &isGrounded, 
                  float playerSpeed, float gravity, float jumpForce,
                  int worldMap[MAP_HEIGHT][MAP_WIDTH], bool isInventoryOpen) {
    
    if (isInventoryOpen) return;

    float horizontalMove = 0.0f;
    if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) horizontalMove += playerSpeed;
    if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) horizontalMove -= playerSpeed;

    playerX += horizontalMove;
    if (playerX < 0) playerX = 0;
    if (playerX > MAP_WIDTH * TILE_SIZE - PLAYER_COLL_WIDTH) playerX = MAP_WIDTH * TILE_SIZE - PLAYER_COLL_WIDTH;

    Rectangle playerRec = { playerX, playerY, PLAYER_COLL_WIDTH, PLAYER_COLL_HEIGHT };
    int left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
    int right  = Clamp((int)((playerX + PLAYER_COLL_WIDTH) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
    int top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
    int bottom = Clamp((int)((playerY + PLAYER_COLL_HEIGHT) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

    for (int y = top; y <= bottom; y++) {
        for (int x = left; x <= right; x++) {
            if (worldMap[y][x] == AIR) continue;
            Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            if (CheckCollisionRecs(playerRec, tileRec)) {
                if (horizontalMove > 0)       playerX = tileRec.x - PLAYER_COLL_WIDTH;
                else if (horizontalMove < 0)  playerX = tileRec.x + TILE_SIZE;
                playerRec.x = playerX;
            }
        }
    }

    if (IsKeyDown(KEY_SPACE) && isGrounded) {
        velocityY = jumpForce;
        isGrounded = false;
    }

    velocityY += gravity;
    playerY += velocityY;
    playerRec = { playerX, playerY, PLAYER_COLL_WIDTH, PLAYER_COLL_HEIGHT };
    isGrounded = false;

    left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
    right  = Clamp((int)((playerX + PLAYER_COLL_WIDTH) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
    top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
    bottom = Clamp((int)((playerY + PLAYER_COLL_HEIGHT) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

    for (int y = top; y <= bottom; y++) {
        for (int x = left; x <= right; x++) {
            if (worldMap[y][x] == AIR) continue;
            Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            if (CheckCollisionRecs(playerRec, tileRec)) {
                if (velocityY > 0) { 
                    playerY = tileRec.y - PLAYER_COLL_HEIGHT;
                    velocityY = 0;
                    isGrounded = true;
                } else if (velocityY < 0) { 
                    playerY = tileRec.y + TILE_SIZE;
                    velocityY = 0;
                }
                playerRec.y = playerY;
            }
        }
    }
}

void UpdateDroppedItems(DroppedItem droppedItems[], float playerX, float playerY, 
                        InventorySlot inventory[], float gravity, int worldMap[MAP_HEIGHT][MAP_WIDTH]) {
    
    float playerCenterX = playerX + PLAYER_COLL_WIDTH / 2.0f;
    float playerCenterY = playerY + PLAYER_COLL_HEIGHT / 2.0f;

    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        if (!droppedItems[i].active) continue;

        int itemSize = 12;
        droppedItems[i].velocityY += gravity;
        droppedItems[i].position.y += droppedItems[i].velocityY;

        Rectangle itemRec = { droppedItems[i].position.x, droppedItems[i].position.y, (float)itemSize, (float)itemSize };
        int left   = Clamp((int)(droppedItems[i].position.x / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
        int right  = Clamp((int)((droppedItems[i].position.x + itemSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
        int top    = Clamp((int)(droppedItems[i].position.y / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
        int bottom = Clamp((int)((droppedItems[i].position.y + itemSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

        for (int y = top; y <= bottom; y++) {
            for (int x = left; x <= right; x++) {
                if (worldMap[y][x] == AIR) continue;
                Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                if (CheckCollisionRecs(itemRec, tileRec)) {
                    if (droppedItems[i].velocityY > 0) {
                        droppedItems[i].position.y = tileRec.y - itemSize;
                        droppedItems[i].velocityY = 0;
                    }
                    itemRec.y = droppedItems[i].position.y;
                }
            }
        }

        float itemCenterX = droppedItems[i].position.x + 6.0f;
        float itemCenterY = droppedItems[i].position.y + 6.0f;
        float distToPlayer = sqrtf((itemCenterX - playerCenterX) * (itemCenterX - playerCenterX) + 
                                   (itemCenterY - playerCenterY) * (itemCenterY - playerCenterY));

        if (distToPlayer < 40.0f) { 
            bool added = false;
            for (int j = 0; j < INVENTORY_SIZE; j++) {
                if (inventory[j].type == droppedItems[i].type && inventory[j].count < 32) {
                    inventory[j].count++;
                    added = true;
                    break;
                }
            }
            if (!added) {
                for (int j = 0; j < INVENTORY_SIZE; j++) {
                    if (inventory[j].type == AIR) {
                        inventory[j].type = droppedItems[i].type;
                        inventory[j].count = 1;
                        added = true;
                        break;
                    }
                }
            }
            if (added) droppedItems[i].active = false;
        }
    }
}

void HandleMouseInteraction(int worldMap[MAP_HEIGHT][MAP_WIDTH], float playerX, float playerY,
                            InventorySlot inventory[], int activeSlot, DroppedItem droppedItems[], Camera2D camera, bool isInventoryOpen) {
    
    if (isInventoryOpen) return;

    Vector2 mouseWorldPos = GetScreenToWorld2D(GetMousePosition(), camera);
    int mouseGridX = mouseWorldPos.x / TILE_SIZE;
    int mouseGridY = mouseWorldPos.y / TILE_SIZE;

    if (mouseGridX < 0 || mouseGridX >= MAP_WIDTH || mouseGridY < 0 || mouseGridY >= MAP_HEIGHT) return;

    float playerCenterX = playerX + PLAYER_COLL_WIDTH / 2.0f;
    float playerCenterY = playerY + PLAYER_COLL_HEIGHT / 2.0f;
    float blockCenterX = mouseGridX * TILE_SIZE + TILE_SIZE / 2.0f;
    float blockCenterY = mouseGridY * TILE_SIZE + TILE_SIZE / 2.0f;
    float distance = sqrtf((blockCenterX - playerCenterX) * (blockCenterX - playerCenterX) + (blockCenterY - playerCenterY) * (blockCenterY - playerCenterY));
    
    if (distance > 4.0f * TILE_SIZE) return;

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        BlockType targetBlock = (BlockType)worldMap[mouseGridY][mouseGridX];
        if (targetBlock != BEDROCK && targetBlock != AIR) {
            worldMap[mouseGridY][mouseGridX] = AIR;

            for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
                if (!droppedItems[i].active) {
                    droppedItems[i].position = (Vector2){ (float)mouseGridX * TILE_SIZE + 10, (float)mouseGridY * TILE_SIZE + 10 };
                    droppedItems[i].type = targetBlock;
                    droppedItems[i].active = true;
                    droppedItems[i].velocityY = 0.0f;
                    break;
                }
            }
        }
    }

    if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
        BlockType selectedBlock = inventory[activeSlot].type;
        if (worldMap[mouseGridY][mouseGridX] == AIR && selectedBlock != AIR && inventory[activeSlot].count > 0) {
            
            Rectangle blockRec = { (float)mouseGridX * TILE_SIZE, (float)mouseGridY * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            Rectangle playerRec = { playerX, playerY, PLAYER_COLL_WIDTH, PLAYER_COLL_HEIGHT };
            
            if (!CheckCollisionRecs(playerRec, blockRec)) {
                worldMap[mouseGridY][mouseGridX] = selectedBlock;
                inventory[activeSlot].count--;
                if (inventory[activeSlot].count == 0) inventory[activeSlot].type = AIR;
            }
        }
    }
}

// ============================================================================
// CÁC HÀM VẼ GIAO DIỆN VÀ ĐỒ HỌA
// ============================================================================

void DrawWorld(int worldMap[MAP_HEIGHT][MAP_WIDTH], DroppedItem droppedItems[], float playerX, float playerY, GameTextures &tex, float gameTime) {
    // Tính toán độ tối của môi trường dựa trên thời gian để tô màu (Tint) lên các block
    Color lighting = WHITE; 
    if (gameTime >= 30.0f) { // Ban đêm thì các block sẽ tối đi
        lighting = GRAY;
    }

    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            int pixelX = x * TILE_SIZE;
            int pixelY = y * TILE_SIZE;

            // Truyền lighting vào thay vì WHITE để mặt đất tối theo thời gian
            if (worldMap[y][x] == DIRT) DrawTexture(tex.dirt, pixelX, pixelY, lighting);
            else if (worldMap[y][x] == GRASS) DrawTexture(tex.grass, pixelX, pixelY, lighting);
            else if (worldMap[y][x] == STONE) DrawTexture(tex.stone, pixelX, pixelY, lighting);
            else if (worldMap[y][x] == BEDROCK) DrawTexture(tex.bedrock, pixelX, pixelY, lighting);
            else if (worldMap[y][x] == WOOD) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, (gameTime >= 30.0f) ? DARKBROWN : ORANGE);
        }
    }

    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        if (droppedItems[i].active) {
            int itemSize = 12;
            Color itemColor = WHITE;
            if (droppedItems[i].type == DIRT) itemColor = BROWN;
            else if (droppedItems[i].type == GRASS) itemColor = DARKGREEN;
            else if (droppedItems[i].type == STONE) itemColor = GRAY;
            else if (droppedItems[i].type == WOOD) itemColor = ORANGE;

            DrawRectangle(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, itemColor);
            DrawRectangleLines(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, BLACK);
        }
    }

    int drawX = (int)(playerX - (32.0f - PLAYER_COLL_WIDTH) / 2.0f);
    int drawY = (int)playerY; 
    DrawTexture(tex.player, drawX, drawY, lighting);
}

void DrawGameUI(bool isInventoryOpen, int activeSlot, InventorySlot inventory[], InventorySlot &heldItem, int screenWidth, int screenHeight, GameTextures &tex) {
    int slotSize = 40;
    int slotGap = 10;
    int hotbarWidth = (slotSize * 4) + (slotGap * 3);
    int hStartX = (screenWidth - hotbarWidth) / 2;
    int hStartY = screenHeight - slotSize - 20;

    for (int i = 0; i < 4; i++) {
        int slotX = hStartX + i * (slotSize + slotGap);
        DrawRectangle(slotX, hStartY, slotSize, slotSize, Fade(BLACK, 0.4f));

        if (i == activeSlot) DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 3, YELLOW);
        else DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 1, WHITE);

        BlockType type = inventory[i].type;
        int count = inventory[i].count;

        if (type != AIR && count > 0) {
            if (type == DIRT) DrawTexture(tex.dirt, slotX + 4, hStartY + 4, WHITE);
            else if (type == GRASS) DrawTexture(tex.grass, slotX + 4, hStartY + 4, WHITE);
            else if (type == STONE) DrawTexture(tex.stone, slotX + 4, hStartY + 4, WHITE);
            
            DrawText(TextFormat("%d", count), slotX + slotSize - 15, hStartY + slotSize - 14, 10, WHITE);
        }
        char numStr[2] = {(char)('1' + i), '\0'};
        DrawText(numStr, slotX + 4, hStartY + 4, 12, LIGHTGRAY);
    }

    DrawText("Nut E: Dong/Mo UI | Phim 1->4: Chon o Hotbar | Chuot T/P: Dap/Dat", 10, 10, 16, WHITE);

    if (isInventoryOpen) {
        DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.6f));

        int invCols = 6, invRows = 2, invSlotSize = 44, invGap = 8;
        int invWidth = (invSlotSize * invCols) + (invGap * (invCols - 1));
        int invHeight = (invSlotSize * invRows) + (invGap * (invRows - 1));
        int invStartX = (screenWidth - invWidth) / 2;
        int invStartY = (screenHeight - invHeight) / 2;

        DrawRectangle(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, Fade(DARKGRAY, 0.9f));
        DrawRectangleLines(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, WHITE);
        DrawText("TUI DO (INVENTORY)", invStartX, invStartY - 30, 16, GOLD);

        for (int r = 0; r < invRows; r++) {
            for (int c = 0; c < invCols; c++) {
                int index = r * invCols + c;
                int slotX = invStartX + c * (invSlotSize + invGap);
                int slotY = invStartY + r * (invSlotSize + invGap);

                Vector2 mousePos = GetMousePosition();
                Rectangle slotRec = { (float)slotX, (float)slotY, (float)invSlotSize, (float)invSlotSize };

                DrawRectangle(slotX, slotY, invSlotSize, invSlotSize, BLACK);

                if (CheckCollisionPointRec(mousePos, slotRec)) {
                    DrawRectangleLinesEx(slotRec, 1, YELLOW);
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                        InventorySlot temp = inventory[index];
                        inventory[index] = heldItem;
                        heldItem = temp;
                    }
                } else {
                    DrawRectangleLines(slotX, slotY, invSlotSize, invSlotSize, GRAY);
                }

                if (inventory[index].type != AIR && inventory[index].count > 0) {
                    BlockType type = inventory[index].type;
                    int itemX = slotX + 6;
                    int itemY = slotY + 6;

                    if (type == DIRT) DrawTexture(tex.dirt, itemX, itemY, WHITE);
                    else if (type == GRASS) DrawTexture(tex.grass, itemX, itemY, WHITE);
                    else if (type == STONE) DrawTexture(tex.stone, itemX, itemY, WHITE);

                    DrawText(TextFormat("%d", inventory[index].count), slotX + invSlotSize - 18, slotY + invSlotSize - 14, 12, WHITE);
                }
            }
        }
    }

    if (isInventoryOpen && heldItem.type != AIR && heldItem.count > 0) {
        Vector2 mousePos = GetMousePosition();
        int itemX = mousePos.x - 16;
        int itemY = mousePos.y - 16;

        if (heldItem.type == DIRT) DrawTexture(tex.dirt, itemX, itemY, WHITE);
        else if (heldItem.type == GRASS) DrawTexture(tex.grass, itemX, itemY, WHITE);
        else if (heldItem.type == STONE) DrawTexture(tex.stone, itemX, itemY, WHITE);

        DrawText(TextFormat("%d", heldItem.count), itemX + 20, itemY + 20, 12, WHITE);
    }
}

// ============================================================================
// HÀM MAIN CHÍNH
// ============================================================================
int main() {
    const int screenWidth = 1280;
    const int screenHeight = 720;
    InitWindow(screenWidth, screenHeight, "Survive Till Dawn");

    GameScreen currentScreen = MENU;
    int highScore = 0; 

    // --- BIẾN THỜI GIAN MỚI ---
    float gameTime = 0.0f;
    int survivedDays = 0;

    GameTextures tex;
    tex.dirt = LoadTexture("asset/dirt.png"); 
    tex.grass = LoadTexture("asset/grass.png");
    tex.stone = LoadTexture("asset/stone.png");
    tex.bedrock = LoadTexture("asset/bedrock.png");
    tex.player = LoadTexture("asset/mainchar.png");
    tex.sun = LoadTexture("asset/sun.png");
    tex.cloud1 = LoadTexture("asset/cloud1.png");
    tex.cloud2 = LoadTexture("asset/cloud2.png");
    tex.cloud2 = LoadTexture("asset/cloud3.png");
    tex.moon = LoadTexture("asset/moon.png");

    float playerX = 150.0f;
    float playerY = 100.0f;
    const float playerSpeed = 5.0f;
    float velocityY = 0.0f;
    const float gravity = 0.5f;
    const float jumpForce = -10.0f;
    bool isGrounded = false;

    int activeSlot = 0;
    bool isInventoryOpen = false;

    InventorySlot inventory[INVENTORY_SIZE];
    for (int i = 0; i < INVENTORY_SIZE; i++) {
        inventory[i].type = AIR;
        inventory[i].count = 0;
    }
    InventorySlot heldItem = { AIR, 0 };

    DroppedItem droppedItems[MAX_DROPPED_ITEMS];
    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        droppedItems[i].active = false;
    }

    Camera2D camera = { 0 };
    camera.offset = (Vector2){ screenWidth / 2.0f, screenHeight / 2.0f };
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;

    int worldMap[MAP_HEIGHT][MAP_WIDTH];
    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        
        if (currentScreen == MENU) {
            Vector2 mousePos = GetMousePosition();

            BeginDrawing();
                ClearBackground(BLACK);
                DrawText("SURVIVE TILL DAWN", screenWidth/2 - MeasureText("SURVIVE TILL DAWN", 80)/2, 150, 80, RED);
                DrawText(TextFormat("High Score: %d", highScore), screenWidth/2 - MeasureText(TextFormat("High Score: %d", highScore), 30)/2, 260, 30, LIGHTGRAY);

                Rectangle playBtn = { screenWidth/2.0f - 125, 380, 250, 70 };
                if (CheckCollisionPointRec(mousePos, playBtn)) {
                    DrawRectangleRec(playBtn, DARKGRAY); 
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                        // Gọi hàm Reset truyền thêm gameTime và survivedDays
                        ResetGame(playerX, playerY, velocityY, worldMap, inventory, droppedItems, gameTime, survivedDays);
                        currentScreen = GAMEPLAY;
                    }
                } else {
                    DrawRectangleRec(playBtn, GRAY);
                }
                DrawRectangleLinesEx(playBtn, 3, WHITE);
                DrawText("PLAY", playBtn.x + 125 - MeasureText("PLAY", 40)/2, playBtn.y + 15, 40, WHITE);

                Rectangle exitBtn = { screenWidth/2.0f - 125, 480, 250, 70 };
                if (CheckCollisionPointRec(mousePos, exitBtn)) {
                    DrawRectangleRec(exitBtn, DARKGRAY);
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                        break; 
                    }
                } else {
                    DrawRectangleRec(exitBtn, GRAY);
                }
                DrawRectangleLinesEx(exitBtn, 3, WHITE);
                DrawText("EXIT", exitBtn.x + 125 - MeasureText("EXIT", 40)/2, exitBtn.y + 15, 40, WHITE);

            EndDrawing();
        }

        else if (currentScreen == GAMEPLAY) {
            
            // --- LOGIC THỜI GIAN VÀ CHU KỲ NGÀY ĐÊM ---
            gameTime += GetFrameTime();
            if (gameTime >= 90.0f) {
                gameTime = 0.0f;
                survivedDays++; // Sang ngày mới!
            }

            // Xử lý đổi màu nền (Bầu trời) theo mốc giây
            Color skyColor = SKYBLUE;
            if (gameTime < 10.0f) {
                skyColor = (Color){ 100, 149, 237, 255 }; // Sáng sớm: Xanh dương đậm
            } else if (gameTime < 20.0f) {
                skyColor = SKYBLUE; // Buổi trưa: Xanh sáng
            } else if (gameTime < 30.0f) {
                skyColor = (Color){ 253, 149, 109, 255 }; // Chiều tà: Cam hoàng hôn
            } else {
                skyColor = (Color){ 15, 20, 40, 255 }; // Đêm: Xanh đen
            }

            // Tính quỹ đạo quay của mặt trời (0 -> 30s) và mặt trăng (30 -> 90s)
            float arcAngle = 0.0f;
            bool isDay = (gameTime < 30.0f);
            
            if (isDay) {
                // Phân tích tiến trình ban ngày (0.0 đến 1.0)
                float dayProgress = gameTime / 30.0f;
                // Góc quay từ trái (PI) sang phải (0)
                arcAngle = PI - (dayProgress * PI);
            } else {
                // Tiến trình ban đêm 60 giây (0.0 đến 1.0)
                float nightProgress = (gameTime - 30.0f) / 60.0f;
                arcAngle = PI - (nightProgress * PI);
            }

            // Tính tọa độ vẽ (dựa trên phương trình đường tròn)
            float radius = screenWidth / 2.2f;
            int celestialX = (screenWidth / 2) + cosf(arcAngle) * radius;
            int celestialY = screenHeight - sinf(arcAngle) * (screenHeight / 1.5f);

            if (IsKeyPressed(KEY_E)) isInventoryOpen = !isInventoryOpen;
            if (!isInventoryOpen) {
                if (IsKeyPressed(KEY_ONE))   activeSlot = 0;
                if (IsKeyPressed(KEY_TWO))   activeSlot = 1;
                if (IsKeyPressed(KEY_THREE)) activeSlot = 2;
                if (IsKeyPressed(KEY_FOUR))  activeSlot = 3;
            }

            UpdatePlayer(playerX, playerY, velocityY, isGrounded, playerSpeed, gravity, jumpForce, worldMap, isInventoryOpen);
            UpdateDroppedItems(droppedItems, playerX, playerY, inventory, gravity, worldMap);
            HandleMouseInteraction(worldMap, playerX, playerY, inventory, activeSlot, droppedItems, camera, isInventoryOpen);

            camera.target = (Vector2){ playerX + PLAYER_COLL_WIDTH / 2.0f, playerY + PLAYER_COLL_HEIGHT / 2.0f };
            if (camera.target.x < screenWidth / 2.0f) camera.target.x = screenWidth / 2.0f;
            if (camera.target.x > (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f) camera.target.x = (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f;
            if (camera.target.y < screenHeight / 2.0f) camera.target.y = screenHeight / 2.0f;
            if (camera.target.y > (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f) camera.target.y = (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f;

            BeginDrawing();
                ClearBackground(skyColor); // Đổi màu nền tự động

                // Vẽ mặt trời / mặt trăng theo tọa độ quỹ đạo
                if (isDay) {
                    DrawTexture(tex.sun, celestialX - tex.sun.width/2, celestialY - tex.sun.height/2, WHITE);
                } else {
                    
                    DrawTexture(tex.moon, celestialX - tex.moon.width/2, celestialY - tex.moon.height/2, WHITE);
                }

                // Vẽ mây (Vào ban đêm mây sẽ tối lại)
                Color cloudTint = isDay ? WHITE : DARKGRAY;
                DrawTexture(tex.cloud1, 100, 60, cloudTint);
                DrawTexture(tex.cloud2, 400, 100, cloudTint);
                DrawTexture(tex.cloud1, 650, 130, cloudTint);
                DrawTexture(tex.cloud3, 800, 120, cloudTint);

                BeginMode2D(camera);
                    DrawWorld(worldMap, droppedItems, playerX, playerY, tex, gameTime);
                EndMode2D();

                DrawGameUI(isInventoryOpen, activeSlot, inventory, heldItem, screenWidth, screenHeight, tex);
            EndDrawing();
        }
    }
    
    UnloadTexture(tex.dirt);
    UnloadTexture(tex.grass);
    UnloadTexture(tex.stone);
    UnloadTexture(tex.bedrock);
    UnloadTexture(tex.player);
    UnloadTexture(tex.sun);
    UnloadTexture(tex.cloud1);
    UnloadTexture(tex.cloud2);
    UnloadTexture(tex.cloud3);
    UnloadTexture(tex.moon);

    CloseWindow();
    return 0;
}