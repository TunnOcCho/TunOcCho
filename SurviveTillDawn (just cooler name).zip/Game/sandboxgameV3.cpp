#include "raylib.h"
#include <cmath> // Để dùng hàm tính khoảng cách sqrtf

// --- CÁC HẰNG SỐ HỆ THỐNG ---
const int MAP_WIDTH = 100;  
const int MAP_HEIGHT = 30; 
const int TILE_SIZE = 32;  
const int MAX_DROPPED_ITEMS = 128; 
const int INVENTORY_SIZE = 12;

// --- ĐỊNH NGHĨA KIỂU DỮ LIỆU (STRUCT thuần túy, không chứa hàm/OOP) ---
enum BlockType {
    AIR = 0,
    DIRT = 1,
    GRASS = 2,
    STONE = 3,
    WOOD = 4,
    BEDROCK = 5 
};

struct InventorySlot {
    BlockType type;
    int count;
};

struct DroppedItem {
    Vector2 position;
    BlockType type;
    bool active;
    float velocityY;
};

// --- CÁC HÀM TOÁN HỌC & BỔ TRỢ ---
int Clamp(int value, int min, int max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

float Hash1D(int x) {
    x = (x << 13) ^ x;
    return (1.0f - ((x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f);
}

float Interpolate(float a, float b, float t) {
    float ft = t * 3.1415927f;
    float f = (1.0f - cosf(ft)) * 0.5f;
    return a * (1.0f - f) + b * f;
}

float GetNoise1D(float x, float frequency) {
    float sampleX = x * frequency;
    int x0 = (int)floorf(sampleX);
    int x1 = x0 + 1;
    float t = sampleX - (float)x0;
    return Interpolate(Hash1D(x0), Hash1D(x1), t);
}

// --- HÀM 1: KHỞI TẠO ĐỊA HÌNH NGẪU NHIÊN CHỨC NĂNG 4 ---
void InitWorldMap(int worldMap[MAP_HEIGHT][MAP_WIDTH]) {
    float frequency = 0.08f; 
    float amplitude = 8.0f;  
    int baseHeight = 15;     

    for (int x = 0; x < MAP_WIDTH; x++) {
        int surfaceY = baseHeight + (int)(GetNoise1D((float)x, frequency) * amplitude);
        surfaceY = Clamp(surfaceY, 3, MAP_HEIGHT - 3);

        for (int y = 0; y < MAP_HEIGHT; y++) {
            if (y == MAP_HEIGHT - 1) {
                worldMap[y][x] = BEDROCK; 
            } else if (y < surfaceY) {
                worldMap[y][x] = AIR;     
            } else if (y == surfaceY) {
                worldMap[y][x] = GRASS;   
            } else if (y > surfaceY && y < surfaceY + 5) {
                worldMap[y][x] = DIRT;    
            } else {
                worldMap[y][x] = STONE;   
            }
        }
    }
}

// --- HÀM 2: CẬP NHẬT DI CHUYỂN VÀ VA CHẠM NHÂN VẬT ---
void UpdatePlayer(float &playerX, float &playerY, float &velocityY, bool &isGrounded, 
                  float playerSize, float playerSpeed, float gravity, float jumpForce,
                  int worldMap[MAP_HEIGHT][MAP_WIDTH], bool isInventoryOpen) {
    
    if (isInventoryOpen) return; // Nếu mở túi đồ thì dừng di chuyển nhân vật

    float horizontalMove = 0.0f;
    if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) horizontalMove += playerSpeed;
    if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) horizontalMove -= playerSpeed;

    playerX += horizontalMove;
    if (playerX < 0) playerX = 0;
    if (playerX > MAP_WIDTH * TILE_SIZE - playerSize) playerX = MAP_WIDTH * TILE_SIZE - playerSize;

    Rectangle playerRec = { playerX, playerY, playerSize, playerSize };

    // Xử lý va chạm trục X
    int left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
    int right  = Clamp((int)((playerX + playerSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
    int top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
    int bottom = Clamp((int)((playerY + playerSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

    for (int y = top; y <= bottom; y++) {
        for (int x = left; x <= right; x++) {
            if (worldMap[y][x] == AIR) continue;
            Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            if (CheckCollisionRecs(playerRec, tileRec)) {
                if (horizontalMove > 0)       playerX = tileRec.x - playerSize;
                else if (horizontalMove < 0)  playerX = tileRec.x + TILE_SIZE;
                playerRec.x = playerX;
            }
        }
    }

    // Nhảy và Trọng lực
    if (IsKeyDown(KEY_SPACE) && isGrounded) {
        velocityY = jumpForce;
        isGrounded = false;
    }

    velocityY += gravity; 
    playerY += velocityY; 

    playerRec = { playerX, playerY, playerSize, playerSize };
    isGrounded = false;

    // Xử lý va chạm trục Y
    left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
    right  = Clamp((int)((playerX + playerSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
    top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
    bottom = Clamp((int)((playerY + playerSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

    for (int y = top; y <= bottom; y++) {
        for (int x = left; x <= right; x++) {
            if (worldMap[y][x] == AIR) continue;
            Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            if (CheckCollisionRecs(playerRec, tileRec)) {
                if (velocityY > 0) {
                    playerY = tileRec.y - playerSize;
                    velocityY = 0;
                    isGrounded = true;
                } else if (velocityY < 0) {
                    playerY = tileRec.y + TILE_SIZE;
                    velocityY = 0;
                }
                playerRec.y = playerY;
            }
        }
    }
}

// --- HÀM 3: CẬP NHẬT VẬT LÝ RƠI VÀ HÚT VẬT PHẨM (TÍNH NĂNG 1) ---
void UpdateDroppedItems(DroppedItem droppedItems[], float playerX, float playerY, float playerSize, 
                        InventorySlot inventory[], float gravity, int worldMap[MAP_HEIGHT][MAP_WIDTH]) {
    
    float playerCenterX = playerX + playerSize / 2.0f;
    float playerCenterY = playerY + playerSize / 2.0f;

    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        if (!droppedItems[i].active) continue;

        // 1. Vật lý rơi tự do và va chạm nền đất
        int itemSize = 12;
        droppedItems[i].velocityY += gravity; 
        droppedItems[i].position.y += droppedItems[i].velocityY; 

        Rectangle itemRec = { droppedItems[i].position.x, droppedItems[i].position.y, (float)itemSize, (float)itemSize };

        int left   = Clamp((int)(droppedItems[i].position.x / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
        int right  = Clamp((int)((droppedItems[i].position.x + itemSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
        int top    = Clamp((int)(droppedItems[i].position.y / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
        int bottom = Clamp((int)((droppedItems[i].position.y + itemSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

        for (int y = top; y <= bottom; y++) {
            for (int x = left; x <= right; x++) {
                if (worldMap[y][x] == AIR) continue;
                Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                if (CheckCollisionRecs(itemRec, tileRec)) {
                    if (droppedItems[i].velocityY > 0) {
                        droppedItems[i].position.y = tileRec.y - itemSize;
                        droppedItems[i].velocityY = 0;
                    }
                    itemRec.y = droppedItems[i].position.y;
                }
            }
        }

        // 2. Logic hút vật phẩm vào túi đồ khi lại gần
        float itemCenterX = droppedItems[i].position.x + 6.0f; 
        float itemCenterY = droppedItems[i].position.y + 6.0f;
        float distToPlayer = sqrtf((itemCenterX - playerCenterX) * (itemCenterX - playerCenterX) + 
                                   (itemCenterY - playerCenterY) * (itemCenterY - playerCenterY));

        if (distToPlayer < 35.0f) {
            bool added = false;
            for (int j = 0; j < INVENTORY_SIZE; j++) {
                if (inventory[j].type == droppedItems[i].type && inventory[j].count < 32) {
                    inventory[j].count++;
                    added = true;
                    break;
                }
            }
            if (!added) {
                for (int j = 0; j < INVENTORY_SIZE; j++) {
                    if (inventory[j].type == AIR) {
                        inventory[j].type = droppedItems[i].type;
                        inventory[j].count = 1;
                        added = true;
                        break;
                    }
                }
            }
            if (added) droppedItems[i].active = false;
        }
    }
}

// --- HÀM 4: XỬ LÝ CLICK ĐẬP BLOCK / ĐẶT BLOCK (TÍNH NĂNG 2) ---
void HandleMouseInteraction(int worldMap[MAP_HEIGHT][MAP_WIDTH], float playerX, float playerY, float playerSize,
                            InventorySlot inventory[], int activeSlot, DroppedItem droppedItems[], Camera2D camera, bool isInventoryOpen) {
    
    if (isInventoryOpen) return;

    Vector2 mouseWorldPos = GetScreenToWorld2D(GetMousePosition(), camera);
    int mouseGridX = mouseWorldPos.x / TILE_SIZE;
    int mouseGridY = mouseWorldPos.y / TILE_SIZE;

    if (mouseGridX < 0 || mouseGridX >= MAP_WIDTH || mouseGridY < 0 || mouseGridY >= MAP_HEIGHT) return;

    float playerCenterX = playerX + playerSize / 2.0f;
    float playerCenterY = playerY + playerSize / 2.0f;
    float blockCenterX = mouseGridX * TILE_SIZE + TILE_SIZE / 2.0f;
    float blockCenterY = mouseGridY * TILE_SIZE + TILE_SIZE / 2.0f;

    float distance = sqrtf((blockCenterX - playerCenterX) * (blockCenterX - playerCenterX) + 
                           (blockCenterY - playerCenterY) * (blockCenterY - playerCenterY));
    
    if (distance > 4.0f * TILE_SIZE) return; // Vượt quá tầm tay phá block

    // CHUỘT TRÁI: PHÁ BLOCK
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        BlockType targetBlock = (BlockType)worldMap[mouseGridY][mouseGridX];
        if (targetBlock != BEDROCK && targetBlock != AIR) {
            worldMap[mouseGridY][mouseGridX] = AIR; 

            for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
                if (!droppedItems[i].active) {
                    droppedItems[i].position = (Vector2){ (float)mouseGridX * TILE_SIZE + 10, (float)mouseGridY * TILE_SIZE + 10 };
                    droppedItems[i].type = targetBlock;
                    droppedItems[i].active = true;
                    droppedItems[i].velocityY = 0.0f;
                    break;
                }
            }
        }
    }
    
    // CHUỘT PHẢI: ĐẶT BLOCK GIỚI HẠN SỐ LƯỢNG
    if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
        BlockType selectedBlock = inventory[activeSlot].type;
        if (worldMap[mouseGridY][mouseGridX] == AIR && selectedBlock != AIR && inventory[activeSlot].count > 0) {
            worldMap[mouseGridY][mouseGridX] = selectedBlock; 
            inventory[activeSlot].count--; 
            if (inventory[activeSlot].count == 0) inventory[activeSlot].type = AIR; 
        }
    }
}

// --- HÀM 5: VẼ THẾ GIỚI GAME (MAP & VẬT PHẨM RƠI) ---
void DrawWorld(int worldMap[MAP_HEIGHT][MAP_WIDTH], DroppedItem droppedItems[], float playerX, float playerY, float playerSize) {
    // Vẽ các khối ô bản đồ
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            int pixelX = x * TILE_SIZE;
            int pixelY = y * TILE_SIZE;

            if (worldMap[y][x] == DIRT) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, BROWN);
            else if (worldMap[y][x] == GRASS) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, DARKGREEN);
            else if (worldMap[y][x] == STONE) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, GRAY);
            else if (worldMap[y][x] == WOOD) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, ORANGE);
            else if (worldMap[y][x] == BEDROCK) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, BLACK);
        }
    }

    // Vẽ vật phẩm rơi
    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        if (droppedItems[i].active) {
            int itemSize = 12;
            Color itemColor = WHITE;
            if (droppedItems[i].type == DIRT) itemColor = BROWN;
            else if (droppedItems[i].type == GRASS) itemColor = DARKGREEN;
            else if (droppedItems[i].type == STONE) itemColor = GRAY;
            else if (droppedItems[i].type == WOOD) itemColor = ORANGE;

            DrawRectangle(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, itemColor);
            DrawRectangleLines(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, BLACK);
        }
    }

    // Vẽ nhân vật
    DrawRectangle(playerX, playerY, playerSize, playerSize, RED);
}

// --- HÀM 6: VẼ GIAO DIỆN UI (HOTBAR & KÉO THẢ INVENTORY TÍNH NĂNG 3) ---
void DrawGameUI(bool isInventoryOpen, int activeSlot, InventorySlot inventory[], InventorySlot &heldItem, int screenWidth, int screenHeight) {
    // 1. Vẽ HUD Hotbar
    int slotSize = 40;
    int slotGap = 10;
    int hotbarWidth = (slotSize * 4) + (slotGap * 3);
    int hStartX = (screenWidth - hotbarWidth) / 2;
    int hStartY = screenHeight - slotSize - 20;

    for (int i = 0; i < 4; i++) {
        int slotX = hStartX + i * (slotSize + slotGap);
        DrawRectangle(slotX, hStartY, slotSize, slotSize, Fade(BLACK, 0.4f)); 

        if (i == activeSlot) DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 3, YELLOW);
        else DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 1, WHITE);

        int itemSize = 24;
        int itemOffset = (slotSize - itemSize) / 2;
        BlockType hotbarItemType = inventory[i].type;
        int hotbarItemCount = inventory[i].count;

        if (hotbarItemType != AIR && hotbarItemCount > 0) {
            if (hotbarItemType == DIRT) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, BROWN);
            else if (hotbarItemType == GRASS) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, DARKGREEN);
            else if (hotbarItemType == STONE) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, GRAY);
            else if (hotbarItemType == WOOD) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, ORANGE);

            DrawText(TextFormat("%d", hotbarItemCount), slotX + slotSize - 15, hStartY + slotSize - 14, 10, WHITE); 
        }

        char numStr[2] = {(char)('1' + i), '\0'};
        DrawText(numStr, slotX + 4, hStartY + 4, 12, LIGHTGRAY);
    }

    DrawText("Nut E: Dong/Mo Inventory | Di lai gan khoi nho de nhat!", 10, 10, 16, WHITE);

    // 2. Vẽ bảng Inventory lớn và xử lý cơ chế click chuyển đồ (Kéo/Thả)
    if (isInventoryOpen) {
        DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.6f));

        int invCols = 6, invRows = 2, invSlotSize = 44, invGap = 8;
        int invWidth = (invSlotSize * invCols) + (invGap * (invCols - 1));
        int invHeight = (invSlotSize * invRows) + (invGap * (invRows - 1));
        int invStartX = (screenWidth - invWidth) / 2;
        int invStartY = (screenHeight - invHeight) / 2;

        DrawRectangle(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, Fade(DARKGRAY, 0.9f));
        DrawRectangleLines(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, WHITE);
        DrawText("TUI DO (INVENTORY) - MAX STACK: 32", invStartX, invStartY - 30, 16, GOLD);

        for (int r = 0; r < invRows; r++) {
            for (int c = 0; c < invCols; c++) {
                int index = r * invCols + c; 
                int slotX = invStartX + c * (invSlotSize + invGap);
                int slotY = invStartY + r * (invSlotSize + invGap);
                
                Vector2 mousePos = GetMousePosition();
                Rectangle slotRec = { (float)slotX, (float)slotY, (float)invSlotSize, (float)invSlotSize };

                DrawRectangle(slotX, slotY, invSlotSize, invSlotSize, BLACK);

                if (CheckCollisionPointRec(mousePos, slotRec)) {
                    DrawRectangleLinesEx(slotRec, 1, YELLOW); 
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                        // Kỹ thuật Hoán vị (Swap) thủ tục thuần túy
                        InventorySlot temp = inventory[index];
                        inventory[index] = heldItem;
                        heldItem = temp;
                    }
                } else {
                    DrawRectangleLines(slotX, slotY, invSlotSize, invSlotSize, GRAY); 
                }

                if (inventory[index].type != AIR && inventory[index].count > 0) {
                    int itemSize = 28;
                    int itemOffset = (invSlotSize - itemSize) / 2;
                    int itemX = slotX + itemOffset;
                    int itemY = slotY + itemOffset;

                    if (inventory[index].type == DIRT) DrawRectangle(itemX, itemY, itemSize, itemSize, BROWN);
                    else if (inventory[index].type == GRASS) DrawRectangle(itemX, itemY, itemSize, itemSize, DARKGREEN);
                    else if (inventory[index].type == STONE) DrawRectangle(itemX, itemY, itemSize, itemSize, GRAY);
                    else if (inventory[index].type == WOOD) DrawRectangle(itemX, itemY, itemSize, itemSize, ORANGE);

                    DrawText(TextFormat("%d", inventory[index].count), slotX + invSlotSize - 18, slotY + invSlotSize - 14, 12, WHITE);
                }
            }
        }
    }

    // 3. Vẽ vật phẩm bám theo con trỏ chuột khi nhấc lên
    if (isInventoryOpen && heldItem.type != AIR && heldItem.count > 0) {
        Vector2 mousePos = GetMousePosition();
        int itemSize = 28;
        int itemX = mousePos.x - itemSize / 2;
        int itemY = mousePos.y - itemSize / 2;

        Color itemColor = WHITE;
        if (heldItem.type == DIRT) itemColor = BROWN;
        else if (heldItem.type == GRASS) itemColor = DARKGREEN;
        else if (heldItem.type == STONE) itemColor = GRAY;
        else if (heldItem.type == WOOD) itemColor = ORANGE;

        DrawRectangle(itemX, itemY, itemSize, itemSize, itemColor);
        DrawRectangleLines(itemX, itemY, itemSize, itemSize, BLACK);
        DrawText(TextFormat("%d", heldItem.count), itemX + itemSize - 10, itemY + itemSize - 10, 12, WHITE);
    }
}

// --- HÀM MAIN: CHỈ QUẢN LÝ KHỞI TẠO VÀ VÒNG LẶP CHÍNH ---
int main() {
    const int screenWidth = 800;
    const int screenHeight = 450;
    InitWindow(screenWidth, screenHeight, "Raylib Sandbox 2D - Procedural Modular Code");

    // Khởi tạo các biến dữ liệu dạng Primitive/Struct thuần túy
    float playerX = 150.0f;
    float playerY = 100.0f; // Đưa nhân vật lên cao chút để tránh kẹt đất khi sinh map ngẫu nhiên
    const float playerSize = 30.0f; 
    const float playerSpeed = 5.0f;
    float velocityY = 0.0f;          
    const float gravity = 0.5f;      
    const float jumpForce = -10.0f;  
    bool isGrounded = false;         

    int activeSlot = 0; 
    bool isInventoryOpen = false; 

    InventorySlot inventory[INVENTORY_SIZE];
    for (int i = 0; i < INVENTORY_SIZE; i++) {
        inventory[i].type = AIR;
        inventory[i].count = 0;
    }
    InventorySlot heldItem = { AIR, 0 };

    DroppedItem droppedItems[MAX_DROPPED_ITEMS];
    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        droppedItems[i].active = false;
    }

    Camera2D camera = { 0 };
    camera.offset = (Vector2){ screenWidth / 2.0f, screenHeight / 2.0f }; 
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;

    int worldMap[MAP_HEIGHT][MAP_WIDTH];
    
    // Gọi hàm khởi tạo bản đồ (Chức năng 4)
    InitWorldMap(worldMap);

    SetTargetFPS(60);

    // VÒNG LẶP GAME CHÍNH (Rất ngắn gọn nhờ phân tách hàm)
    while (!WindowShouldClose()) {
        
        if (IsKeyPressed(KEY_E)) isInventoryOpen = !isInventoryOpen;

        if (!isInventoryOpen) {
            if (IsKeyPressed(KEY_ONE))   activeSlot = 0;
            if (IsKeyPressed(KEY_TWO))   activeSlot = 1;
            if (IsKeyPressed(KEY_THREE)) activeSlot = 2;
            if (IsKeyPressed(KEY_FOUR))  activeSlot = 3;
        }

        // Gọi các hàm xử lý Logic (Update)
        UpdatePlayer(playerX, playerY, velocityY, isGrounded, playerSize, playerSpeed, gravity, jumpForce, worldMap, isInventoryOpen);
        UpdateDroppedItems(droppedItems, playerX, playerY, playerSize, inventory, gravity, worldMap);
        HandleMouseInteraction(worldMap, playerX, playerY, playerSize, inventory, activeSlot, droppedItems, camera, isInventoryOpen);

        // Cập nhật Camera bám theo nhân vật
        camera.target = (Vector2){ playerX + playerSize / 2.0f, playerY + playerSize / 2.0f };
        if (camera.target.x < screenWidth / 2.0f) camera.target.x = screenWidth / 2.0f;
        if (camera.target.x > (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f) camera.target.x = (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f;
        if (camera.target.y < screenHeight / 2.0f) camera.target.y = screenHeight / 2.0f;
        if (camera.target.y > (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f) camera.target.y = (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f;

        // Gọi các hàm xử lý Đồ họa (Render)
        BeginDrawing();
            ClearBackground(SKYBLUE);

            BeginMode2D(camera);
                DrawWorld(worldMap, droppedItems, playerX, playerY, playerSize);
            EndMode2D();

            DrawGameUI(isInventoryOpen, activeSlot, inventory, heldItem, screenWidth, screenHeight);
        EndDrawing();
    }

    CloseWindow();
    return 0;
}