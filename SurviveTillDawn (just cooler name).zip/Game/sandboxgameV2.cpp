#include "raylib.h"
#include <cmath> // Để dùng hàm tính khoảng cách sqrtf

const int MAP_WIDTH = 100;  
const int MAP_HEIGHT = 30; 
const int TILE_SIZE = 32;  
const int MAX_DROPPED_ITEMS = 128; // Tối đa 128 vật phẩm rơi trên map cùng lúc



enum BlockType {
    AIR = 0,
    DIRT = 1,
    GRASS = 2,
    STONE = 3,
    WOOD = 4,
    BEDROCK = 5 
};

// --- CẤU TRÚC DỮ LIỆU MỚI CHO CHỨC NĂNG Inventory ---
struct InventorySlot {
    BlockType type;
    int count;
};

struct DroppedItem {
    Vector2 position;
    BlockType type;
    bool active;
    float velocityY;
};

int Clamp(int value, int min, int max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

int main() {
    const int screenWidth = 800;
    const int screenHeight = 450;
    InitWindow(screenWidth, screenHeight, "Raylib Sandbox 2D - Item Drops & Stacking");

    float playerX = 150.0f;
    float playerY = 200.0f;
    const float playerSize = 30.0f; 
    const float playerSpeed = 5.0f;

    float velocityY = 0.0f;          
    const float gravity = 0.5f;      
    const float jumpForce = -10.0f;  
    bool isGrounded = false;         

    // HOTBAR 
    
    int activeSlot = 0; 

    // INVENTORY 2x6 (Khởi tạo túi đồ trống hoàn toàn để người chơi đi nhặt vật phẩm)
    bool isInventoryOpen = false; 
    InventorySlot inventory[12];
    for (int i = 0; i < 12; i++) {
        inventory[i].type = AIR;
        inventory[i].count = 0;
    }

    InventorySlot heldItem = { AIR, 0 }; // Vật phẩm đang được click giữ trên con trỏ chuột

    // Khởi tạo mảng quản lý các vật phẩm rơi dưới đất
    DroppedItem droppedItems[MAX_DROPPED_ITEMS];
    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        droppedItems[i].active = false;
    }

    Camera2D camera = { 0 };
    camera.offset = (Vector2){ screenWidth / 2.0f, screenHeight / 2.0f }; 
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;

    SetTargetFPS(60);

    int worldMap[MAP_HEIGHT][MAP_WIDTH];
    for (int y = 0; y < MAP_HEIGHT; y++) {        
        for (int x = 0; x < MAP_WIDTH; x++) {    
            if (y == MAP_HEIGHT - 1) worldMap[y][x] = BEDROCK; 
            else if (y < 12) worldMap[y][x] = AIR;     
            else if (y == 12) worldMap[y][x] = GRASS;   
            else if (y > 12 && y < 22) worldMap[y][x] = DIRT;    
            else worldMap[y][x] = STONE;   
        }
    }

    while (!WindowShouldClose()) {
        
        if (IsKeyPressed(KEY_E)) {
            isInventoryOpen = !isInventoryOpen;
        }

        float horizontalMove = 0.0f;

        if (!isInventoryOpen) {
            if (IsKeyPressed(KEY_ONE))   activeSlot = 0;
            if (IsKeyPressed(KEY_TWO))   activeSlot = 1;
            if (IsKeyPressed(KEY_THREE)) activeSlot = 2;
            if (IsKeyPressed(KEY_FOUR))  activeSlot = 3;

            if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) horizontalMove += playerSpeed;
            if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) horizontalMove -= playerSpeed;

            playerX += horizontalMove;
            if (playerX < 0) playerX = 0;
            if (playerX > MAP_WIDTH * TILE_SIZE - playerSize) playerX = MAP_WIDTH * TILE_SIZE - playerSize;

            Rectangle playerRec = { playerX, playerY, playerSize, playerSize };

            // Va chạm trục X
            int left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
            int right  = Clamp((int)((playerX + playerSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
            int top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
            int bottom = Clamp((int)((playerY + playerSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

            for (int y = top; y <= bottom; y++) {
                for (int x = left; x <= right; x++) {
                    if (worldMap[y][x] == AIR) continue;
                    Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                    if (CheckCollisionRecs(playerRec, tileRec)) {
                        if (horizontalMove > 0)       playerX = tileRec.x - playerSize;
                        else if (horizontalMove < 0)  playerX = tileRec.x + TILE_SIZE;
                        playerRec.x = playerX;
                    }
                }
            }

            if (IsKeyDown(KEY_SPACE) && isGrounded) {
                velocityY = jumpForce;
                isGrounded = false;
            }

            velocityY += gravity; 
            playerY += velocityY; 

            playerRec = { playerX, playerY, playerSize, playerSize };
            isGrounded = false;

            // Va chạm trục Y
            left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
            right  = Clamp((int)((playerX + playerSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
            top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
            bottom = Clamp((int)((playerY + playerSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

            for (int y = top; y <= bottom; y++) {
                for (int x = left; x <= right; x++) {
                    if (worldMap[y][x] == AIR) continue;
                    Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                    if (CheckCollisionRecs(playerRec, tileRec)) {
                        if (velocityY > 0) {
                            playerY = tileRec.y - playerSize;
                            velocityY = 0;
                            isGrounded = true;
                        }
                        else if (velocityY < 0) {
                            playerY = tileRec.y + TILE_SIZE;
                            velocityY = 0;
                        }
                        playerRec.y = playerY;
                    }
                }
            }

            // --- LOGIC HÚT VẬT PHẨM VÀO INVENTORY  ---
            float playerCenterX = playerX + playerSize / 2.0f;
            float playerCenterY = playerY + playerSize / 2.0f;

            for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
                if (droppedItems[i].active) {
                    float itemCenterX = droppedItems[i].position.x + 6.0f; // Tâm vật phẩm thu nhỏ (12x12)
                    float itemCenterY = droppedItems[i].position.y + 6.0f;

                    float distToPlayer = sqrtf((itemCenterX - playerCenterX) * (itemCenterX - playerCenterX) + 
                                               (itemCenterY - playerCenterY) * (itemCenterY - playerCenterY));

                    // Nếu người chơi tiến lại gần trong bán kính 35 pixel -> Tiến hành hút vật phẩm
                    if (distToPlayer < 35.0f) {
                        bool added = false;

                        // Bước 1: Tìm ô đồ đã có sẵn loại block này và chưa đầy (kiểm tra giới hạn stack 32)
                        for (int j = 0; j < 12; j++) {
                            if (inventory[j].type == droppedItems[i].type && inventory[j].count < 32) {
                                inventory[j].count++;
                                added = true;
                                break;
                            }
                        }

                        // Bước 2: Nếu không tìm thấy stack cũ, tìm ô trống (AIR) mới để nhét vào
                        if (!added) {
                            for (int j = 0; j < 12; j++) {
                                if (inventory[j].type == AIR) {
                                    inventory[j].type = droppedItems[i].type;
                                    inventory[j].count = 1;
                                    added = true;
                                    break;
                                }
                            }
                        }

                        // Nếu đã thêm vào túi thành công thì xóa vật phẩm đó trên mặt đất
                        if (added) {
                            droppedItems[i].active = false;
                        }
                    }
                }
            }
        }

        BlockType selectedBlock = inventory[activeSlot].type;

        camera.target = (Vector2){ playerX + playerSize / 2.0f, playerY + playerSize / 2.0f };
        if (camera.target.x < screenWidth / 2.0f) camera.target.x = screenWidth / 2.0f;
        if (camera.target.x > (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f) camera.target.x = (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f;
        if (camera.target.y < screenHeight / 2.0f) camera.target.y = screenHeight / 2.0f;
        if (camera.target.y > (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f) camera.target.y = (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f;

        // XỬ LÝ CHUỘT PHÁ BLOCK -> RƠI RA BLOCK THU NHỎ
        Vector2 mouseWorldPos = GetScreenToWorld2D(GetMousePosition(), camera);
        int mouseGridX = mouseWorldPos.x / TILE_SIZE;
        int mouseGridY = mouseWorldPos.y / TILE_SIZE;

        if (!isInventoryOpen && mouseGridX >= 0 && mouseGridX < MAP_WIDTH && mouseGridY >= 0 && mouseGridY < MAP_HEIGHT) {
            float playerCenterX = playerX + playerSize / 2.0f;
            float playerCenterY = playerY + playerSize / 2.0f;
            float blockCenterX = mouseGridX * TILE_SIZE + TILE_SIZE / 2.0f;
            float blockCenterY = mouseGridY * TILE_SIZE + TILE_SIZE / 2.0f;

            float distance = sqrtf((blockCenterX - playerCenterX) * (blockCenterX - playerCenterX) + 
                                   (blockCenterY - playerCenterY) * (blockCenterY - playerCenterY));
            
            const float MAX_REACH = 4.0f * TILE_SIZE;

            if (distance <= MAX_REACH) {
                // CHUỘT TRÁI: PHÁ BLOCK & GIẢ LẬP RƠI VẬT PHẨM THU NHỎ
                if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                    BlockType targetBlock = (BlockType)worldMap[mouseGridY][mouseGridX];
                    
                    if (targetBlock != BEDROCK && targetBlock != AIR) {
                        worldMap[mouseGridY][mouseGridX] = AIR; // Xóa block trên map

                        // Tạo một thực thể vật phẩm rơi tự do tại tâm ô vừa phá
                        for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
                            if (!droppedItems[i].active) {
                                // Đặt vị trí vật phẩm thu nhỏ nằm căn giữa ô (kích thước 12x12 nên offset là (32-12)/2 = 10)
                                droppedItems[i].position = (Vector2){ (float)mouseGridX * TILE_SIZE + 10, (float)mouseGridY * TILE_SIZE + 10 };
                                droppedItems[i].type = targetBlock;
                                droppedItems[i].active = true;
                                droppedItems[i].velocityY = 0.0f;
                                break;
                            }
                        }
                    }
                }
                if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
                    // Chỉ cho phép đặt nếu ô đang chọn có khối (không phải AIR) và số lượng > 0
                    if (worldMap[mouseGridY][mouseGridX] == AIR && selectedBlock != AIR && inventory[activeSlot].count > 0) {
                        
                        worldMap[mouseGridY][mouseGridX] = selectedBlock; // Đặt khối lên map
                        inventory[activeSlot].count--; // Giảm số lượng đi 1

                        // Nếu đặt hết khối cuối cùng, chuyển ô đó về trạng thái AIR (Trống)
                        if (inventory[activeSlot].count == 0) {
                            inventory[activeSlot].type = AIR; 
                        }
                    }
                }
            }
        }
        // --- LOGIC VẬT LÝ RƠI VÀ VA CHẠM CỦA VẬT PHẨM ---
        for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
            if (droppedItems[i].active) {
                int itemSize = 12; // Kích thước của vật phẩm rơi

                // 1. Áp dụng trọng lực cho vật phẩm
                droppedItems[i].velocityY += gravity; 
                droppedItems[i].position.y += droppedItems[i].velocityY; 

                // 2. Tạo Rectangle giả lập cho vật phẩm để tính toán va chạm
                Rectangle itemRec = { droppedItems[i].position.x, droppedItems[i].position.y, (float)itemSize, (float)itemSize };

                // 3. Giới hạn phạm vi kiểm tra các ô xung quanh vật phẩm nhằm tối ưu hiệu năng
                int left   = Clamp((int)(droppedItems[i].position.x / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
                int right  = Clamp((int)((droppedItems[i].position.x + itemSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
                int top    = Clamp((int)(droppedItems[i].position.y / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
                int bottom = Clamp((int)((droppedItems[i].position.y + itemSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

                // 4. Vòng lặp quét va chạm địa hình (chủ yếu là trục Y để vật phẩm đứng trên đất)
                for (int y = top; y <= bottom; y++) {
                    for (int x = left; x <= right; x++) {
                        if (worldMap[y][x] == AIR) continue; // Bỏ qua nếu là không khí

                        Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                        
                        if (CheckCollisionRecs(itemRec, tileRec)) {
                            // Nếu đang rơi xuống và chạm đất
                            if (droppedItems[i].velocityY > 0) {
                                droppedItems[i].position.y = tileRec.y - itemSize; // Đẩy vật phẩm lên mặt khối
                                droppedItems[i].velocityY = 0; // Dừng rơi
                            }
                            // Nếu bị kẹt đi lên (hiếm khi xảy ra nhưng vẫn phòng hờ)
                            else if (droppedItems[i].velocityY < 0) {
                                droppedItems[i].position.y = tileRec.y + TILE_SIZE;
                                droppedItems[i].velocityY = 0;
                            }
                            itemRec.y = droppedItems[i].position.y; // Cập nhật lại hitbox
                        }
                    }
                }
            }
        }


        // VẼ ĐỒ HỌA
        BeginDrawing();
            ClearBackground(SKYBLUE);

            BeginMode2D(camera);
                // Vẽ bản đồ
                for (int y = 0; y < MAP_HEIGHT; y++) {
                    for (int x = 0; x < MAP_WIDTH; x++) {
                        int pixelX = x * TILE_SIZE;
                        int pixelY = y * TILE_SIZE;

                        if (worldMap[y][x] == DIRT) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, BROWN);
                        else if (worldMap[y][x] == GRASS) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, DARKGREEN);
                        else if (worldMap[y][x] == STONE) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, GRAY);
                        else if (worldMap[y][x] == WOOD) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, ORANGE);
                        else if (worldMap[y][x] == BEDROCK) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, BLACK);
                    }
                }

                // --- VẼ CÁC VẬT PHẨM THU NHỎ ĐANG RƠI TRÊN ĐẤT ---
                for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
                    if (droppedItems[i].active) {
                        int itemSize = 12; // Kích thước thu nhỏ chỉ bằng ~1/3 block gốc
                        Color itemColor = WHITE;
                        if (droppedItems[i].type == DIRT) itemColor = BROWN;
                        else if (droppedItems[i].type == GRASS) itemColor = DARKGREEN;
                        else if (droppedItems[i].type == STONE) itemColor = GRAY;
                        else if (droppedItems[i].type == WOOD) itemColor = ORANGE;

                        // Vẽ khối vuông nhỏ kèm viền đen mỏng tạo cảm giác khối 3D tách biệt đất nền
                        DrawRectangle(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, itemColor);
                        DrawRectangleLines(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, BLACK);
                    }
                }

                // Vẽ nhân vật
                DrawRectangle(playerX, playerY, playerSize, playerSize, RED);
            EndMode2D();

            // VẼ HUD HOTBAR
            int slotSize = 40;
            int slotGap = 10;
            int hotbarWidth = (slotSize * 4) + (slotGap * 3);
            int hStartX = (screenWidth - hotbarWidth) / 2;
            int hStartY = screenHeight - slotSize - 20;

            for (int i = 0; i < 4; i++) {
                int slotX = hStartX + i * (slotSize + slotGap);
                DrawRectangle(slotX, hStartY, slotSize, slotSize, Fade(BLACK, 0.4f)); 

                if (i == activeSlot) {
                    DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 3, YELLOW);
                } else {
                    DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 1, WHITE);
                }

                int itemSize = 24;
                int itemOffset = (slotSize - itemSize) / 2;
                BlockType hotbarItemType = inventory[i].type;
                int hotbarItemCount = inventory[i].count;

                if (hotbarItemType != AIR && hotbarItemCount > 0) {
                    if (hotbarItemType == DIRT) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, BROWN);
                    else if (hotbarItemType == GRASS) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, DARKGREEN);
                    else if (hotbarItemType == STONE) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, GRAY);
                    else if (hotbarItemType == WOOD) DrawRectangle(slotX + itemOffset, hStartY + itemOffset, itemSize, itemSize, ORANGE);

                    // Vẽ thêm số lượng hiển thị trên Hotbar để người chơi dễ nhìn giống trong Inventory
                    DrawText(TextFormat("%d", hotbarItemCount), slotX + slotSize - 15, hStartY + slotSize - 14, 10, WHITE); 
                }

                char numStr[2] = {(char)('1' + i), '\0'};
                DrawText(numStr, slotX + 4, hStartY + 4, 12, LIGHTGRAY);
            }

            DrawText("Nut E: Dong/Mo Inventory | Di lai gan khoi nho de nhat!", 10, 10, 16, WHITE);

            // VẼ GIAO DIỆN INVENTORY ĐÈ LÊN KÈM SỐ LƯỢNG STACK
            if (isInventoryOpen) {
                DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.6f));

                int invCols = 6;
                int invRows = 2;
                int invSlotSize = 44;
                int invGap = 8;
                int invWidth = (invSlotSize * invCols) + (invGap * (invCols - 1));
                int invHeight = (invSlotSize * invRows) + (invGap * (invRows - 1));
                
                int invStartX = (screenWidth - invWidth) / 2;
                int invStartY = (screenHeight - invHeight) / 2;

                DrawRectangle(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, Fade(DARKGRAY, 0.9f));
                DrawRectangleLines(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, WHITE);
                DrawText("TUI DO (INVENTORY) - MAX STACK: 32", invStartX, invStartY - 30, 16, GOLD);

                for (int r = 0; r < invRows; r++) {
                    for (int c = 0; c < invCols; c++) {
                        int index = r * invCols + c; 
                        
                        int slotX = invStartX + c * (invSlotSize + invGap);
                        int slotY = invStartY + r * (invSlotSize + invGap);
                        
                        Vector2 mousePos = GetMousePosition(); // UI dùng tọa độ màn hình (Screen Position)
                        Rectangle slotRec = { (float)slotX, (float)slotY, (float)invSlotSize, (float)invSlotSize };

                        // Kiểm tra nếu chuột đang lơ lửng trên ô đồ này
                        if (CheckCollisionPointRec(mousePos, slotRec)) {
                            // Đổi viền ô thành màu vàng khi rê chuột qua cho đẹp mắt
                            DrawRectangleLinesEx(slotRec, 1, YELLOW); 

                            // Nếu người chơi nhấn chuột trái
                            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                                // Tráo đổi (Swap) vật phẩm trong ô và vật phẩm đang cầm trên tay
                                InventorySlot temp = inventory[index];
                                inventory[index] = heldItem;
                                heldItem = temp;
                            }
                        } else {
                            DrawRectangleLines(slotX, slotY, invSlotSize, invSlotSize, GRAY); // Viền xám mặc định 
                        }

        DrawRectangle(slotX, slotY, invSlotSize, invSlotSize, BLACK);

                        DrawRectangle(slotX, slotY, invSlotSize, invSlotSize, BLACK);
                        

                        // Vẽ vật phẩm bên trong
                        if (inventory[index].type != AIR && inventory[index].count > 0) {
                            int itemSize = 28;
                            int itemOffset = (invSlotSize - itemSize) / 2;
                            int itemX = slotX + itemOffset;
                            int itemY = slotY + itemOffset;

                            if (inventory[index].type == DIRT) DrawRectangle(itemX, itemY, itemSize, itemSize, BROWN);
                            else if (inventory[index].type == GRASS) DrawRectangle(itemX, itemY, itemSize, itemSize, DARKGREEN);
                            else if (inventory[index].type == STONE) DrawRectangle(itemX, itemY, itemSize, itemSize, GRAY);
                            else if (inventory[index].type == WOOD) DrawRectangle(itemX, itemY, itemSize, itemSize, ORANGE);

                            // --- VẼ SỐ LƯỢNG VẬT PHẨM TRONG STACK ---
                            DrawText(TextFormat("%d", inventory[index].count), slotX + invSlotSize - 18, slotY + invSlotSize - 14, 12, WHITE);
                        }
                    }
                }
            }

            // --- VẼ VẬT PHẨM ĐANG CẦM TRÊN TAY THEO CHUỘT ---
            if (isInventoryOpen && heldItem.type != AIR && heldItem.count > 0) {
                Vector2 mousePos = GetMousePosition();
                int itemSize = 28;
                // Căn lề cho vật phẩm nằm ngay tâm con trỏ chuột
                int itemX = mousePos.x - itemSize / 2;
                int itemY = mousePos.y - itemSize / 2;

                Color itemColor = WHITE;
                if (heldItem.type == DIRT) itemColor = BROWN;
                else if (heldItem.type == GRASS) itemColor = DARKGREEN;
                else if (heldItem.type == STONE) itemColor = GRAY;
                else if (heldItem.type == WOOD) itemColor = ORANGE;

                // Vẽ khối vuông nhỏ đang cầm
                DrawRectangle(itemX, itemY, itemSize, itemSize, itemColor);
                DrawRectangleLines(itemX, itemY, itemSize, itemSize, BLACK);
                // Vẽ số lượng đi kèm
                DrawText(TextFormat("%d", heldItem.count), itemX + itemSize - 10, itemY + itemSize - 10, 12, WHITE);
            }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}