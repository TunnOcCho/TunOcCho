#include "raylib.h"
#include <cmath> // Để dùng hàm tính khoảng cách sqrtf

// ============================================================================
// CÁC HẰNG SỐ HỆ THỐNG VÀ KÍCH THƯỚC VẬT LÝ
// ============================================================================
const int MAP_WIDTH = 100;  
const int MAP_HEIGHT = 30; 
const int TILE_SIZE = 32;  
const int MAX_DROPPED_ITEMS = 128; 
const int INVENTORY_SIZE = 12;

// VÁ LỖI 2: Tách biệt kích thước va chạm nhỏ hơn kích thước hình ảnh để di chuyển mượt mà qua khe hẹp
const float PLAYER_COLL_WIDTH = 22.0f;  
const float PLAYER_COLL_HEIGHT = 32.0f; 

struct GameTextures {
    Texture2D dirt;
    Texture2D grass; 
    Texture2D stone;
    Texture2D bedrock;
    Texture2D player;
    Texture2D sun;
    Texture2D cloud1;
    Texture2D cloud2;
};

enum BlockType {
    AIR = 0,
    DIRT = 1,
    GRASS = 2,
    STONE = 3,
    WOOD = 4,
    BEDROCK = 5 
};

struct InventorySlot {
    BlockType type;
    int count;
};

struct DroppedItem {
    Vector2 position;
    BlockType type;
    bool active;
    float velocityY;
};

int Clamp(int value, int min, int max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

// ============================================================================
// CÁC HÀM CẬP NHẬT LOGIC GAME
// ============================================================================

void UpdatePlayer(float &playerX, float &playerY, float &velocityY, bool &isGrounded, 
                  float playerSpeed, float gravity, float jumpForce,
                  int worldMap[MAP_HEIGHT][MAP_WIDTH], bool isInventoryOpen) {
    
    if (isInventoryOpen) return;

    float horizontalMove = 0.0f;
    if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) horizontalMove += playerSpeed;
    if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) horizontalMove -= playerSpeed;

    playerX += horizontalMove;
    if (playerX < 0) playerX = 0;
    if (playerX > MAP_WIDTH * TILE_SIZE - PLAYER_COLL_WIDTH) playerX = MAP_WIDTH * TILE_SIZE - PLAYER_COLL_WIDTH;

    // Áp dụng kích thước va chạm mới
    Rectangle playerRec = { playerX, playerY, PLAYER_COLL_WIDTH, PLAYER_COLL_HEIGHT };
    int left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
    int right  = Clamp((int)((playerX + PLAYER_COLL_WIDTH) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
    int top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
    int bottom = Clamp((int)((playerY + PLAYER_COLL_HEIGHT) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

    // Xử lý va chạm trục X
    for (int y = top; y <= bottom; y++) {
        for (int x = left; x <= right; x++) {
            if (worldMap[y][x] == AIR) continue;
            Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            if (CheckCollisionRecs(playerRec, tileRec)) {
                if (horizontalMove > 0)       playerX = tileRec.x - PLAYER_COLL_WIDTH;
                else if (horizontalMove < 0)  playerX = tileRec.x + TILE_SIZE;
                playerRec.x = playerX;
            }
        }
    }

    if (IsKeyDown(KEY_SPACE) && isGrounded) {
        velocityY = jumpForce;
        isGrounded = false;
    }

    velocityY += gravity;
    playerY += velocityY;
    playerRec = { playerX, playerY, PLAYER_COLL_WIDTH, PLAYER_COLL_HEIGHT };
    isGrounded = false;

    left   = Clamp((int)(playerX / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
    right  = Clamp((int)((playerX + PLAYER_COLL_WIDTH) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
    top    = Clamp((int)(playerY / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
    bottom = Clamp((int)((playerY + PLAYER_COLL_HEIGHT) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

    // Xử lý va chạm trục Y
    for (int y = top; y <= bottom; y++) {
        for (int x = left; x <= right; x++) {
            if (worldMap[y][x] == AIR) continue;
            Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            if (CheckCollisionRecs(playerRec, tileRec)) {
                if (velocityY > 0) { 
                    playerY = tileRec.y - PLAYER_COLL_HEIGHT;
                    velocityY = 0;
                    isGrounded = true;
                } else if (velocityY < 0) { 
                    playerY = tileRec.y + TILE_SIZE;
                    velocityY = 0;
                }
                playerRec.y = playerY;
            }
        }
    }
}

void UpdateDroppedItems(DroppedItem droppedItems[], float playerX, float playerY, 
                        InventorySlot inventory[], float gravity, int worldMap[MAP_HEIGHT][MAP_WIDTH]) {
    
    // Đồng bộ tâm hút vật phẩm theo kích thước va chạm mới của nhân vật
    float playerCenterX = playerX + PLAYER_COLL_WIDTH / 2.0f;
    float playerCenterY = playerY + PLAYER_COLL_HEIGHT / 2.0f;

    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        if (!droppedItems[i].active) continue;

        int itemSize = 12;
        droppedItems[i].velocityY += gravity;
        droppedItems[i].position.y += droppedItems[i].velocityY;

        Rectangle itemRec = { droppedItems[i].position.x, droppedItems[i].position.y, (float)itemSize, (float)itemSize };
        int left   = Clamp((int)(droppedItems[i].position.x / TILE_SIZE) - 1, 0, MAP_WIDTH - 1);
        int right  = Clamp((int)((droppedItems[i].position.x + itemSize) / TILE_SIZE) + 1, 0, MAP_WIDTH - 1);
        int top    = Clamp((int)(droppedItems[i].position.y / TILE_SIZE) - 1, 0, MAP_HEIGHT - 1);
        int bottom = Clamp((int)((droppedItems[i].position.y + itemSize) / TILE_SIZE) + 1, 0, MAP_HEIGHT - 1);

        for (int y = top; y <= bottom; y++) {
            for (int x = left; x <= right; x++) {
                if (worldMap[y][x] == AIR) continue;
                Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                if (CheckCollisionRecs(itemRec, tileRec)) {
                    if (droppedItems[i].velocityY > 0) {
                        droppedItems[i].position.y = tileRec.y - itemSize;
                        droppedItems[i].velocityY = 0;
                    }
                    itemRec.y = droppedItems[i].position.y;
                }
            }
        }

        float itemCenterX = droppedItems[i].position.x + 6.0f;
        float itemCenterY = droppedItems[i].position.y + 6.0f;
        float distToPlayer = sqrtf((itemCenterX - playerCenterX) * (itemCenterX - playerCenterX) + 
                                   (itemCenterY - playerCenterY) * (itemCenterY - playerCenterY));

        if (distToPlayer < 40.0f) { // Tăng nhẹ tầm hút để nhặt đồ trong ngách dễ hơn
            bool added = false;
            for (int j = 0; j < INVENTORY_SIZE; j++) {
                if (inventory[j].type == droppedItems[i].type && inventory[j].count < 32) {
                    inventory[j].count++;
                    added = true;
                    break;
                }
            }
            if (!added) {
                for (int j = 0; j < INVENTORY_SIZE; j++) {
                    if (inventory[j].type == AIR) {
                        inventory[j].type = droppedItems[i].type;
                        inventory[j].count = 1;
                        added = true;
                        break;
                    }
                }
            }
            if (added) droppedItems[i].active = false;
        }
    }
}

void HandleMouseInteraction(int worldMap[MAP_HEIGHT][MAP_WIDTH], float playerX, float playerY,
                            InventorySlot inventory[], int activeSlot, DroppedItem droppedItems[], Camera2D camera, bool isInventoryOpen) {
    
    if (isInventoryOpen) return;

    Vector2 mouseWorldPos = GetScreenToWorld2D(GetMousePosition(), camera);
    int mouseGridX = mouseWorldPos.x / TILE_SIZE;
    int mouseGridY = mouseWorldPos.y / TILE_SIZE;

    if (mouseGridX < 0 || mouseGridX >= MAP_WIDTH || mouseGridY < 0 || mouseGridY >= MAP_HEIGHT) return;

    float playerCenterX = playerX + PLAYER_COLL_WIDTH / 2.0f;
    float playerCenterY = playerY + PLAYER_COLL_HEIGHT / 2.0f;
    float blockCenterX = mouseGridX * TILE_SIZE + TILE_SIZE / 2.0f;
    float blockCenterY = mouseGridY * TILE_SIZE + TILE_SIZE / 2.0f;
    float distance = sqrtf((blockCenterX - playerCenterX) * (blockCenterX - playerCenterX) + (blockCenterY - playerCenterY) * (blockCenterY - playerCenterY));
    
    if (distance > 4.0f * TILE_SIZE) return;

    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        BlockType targetBlock = (BlockType)worldMap[mouseGridY][mouseGridX];
        if (targetBlock != BEDROCK && targetBlock != AIR) {
            worldMap[mouseGridY][mouseGridX] = AIR;

            for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
                if (!droppedItems[i].active) {
                    droppedItems[i].position = (Vector2){ (float)mouseGridX * TILE_SIZE + 10, (float)mouseGridY * TILE_SIZE + 10 };
                    droppedItems[i].type = targetBlock;
                    droppedItems[i].active = true;
                    droppedItems[i].velocityY = 0.0f;
                    break;
                }
            }
        }
    }

    if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
        BlockType selectedBlock = inventory[activeSlot].type;
        if (worldMap[mouseGridY][mouseGridX] == AIR && selectedBlock != AIR && inventory[activeSlot].count > 0) {
            
            // VÁ LỖI 1: Tạo khung bao của ô vuông chuẩn bị đặt
            Rectangle blockRec = { (float)mouseGridX * TILE_SIZE, (float)mouseGridY * TILE_SIZE, TILE_SIZE, TILE_SIZE };
            Rectangle playerRec = { playerX, playerY, PLAYER_COLL_WIDTH, PLAYER_COLL_HEIGHT };
            
            // Chỉ cho phép đặt block khi vị trí đó KHÔNG đè/va chạm vào người chơi
            if (!CheckCollisionRecs(playerRec, blockRec)) {
                worldMap[mouseGridY][mouseGridX] = selectedBlock;
                inventory[activeSlot].count--;
                if (inventory[activeSlot].count == 0) inventory[activeSlot].type = AIR;
            }
        }
    }
}

// ============================================================================
// CÁC HÀM VẼ GIAO DIỆN VÀ ĐỒ HỌA
// ============================================================================

void DrawWorld(int worldMap[MAP_HEIGHT][MAP_WIDTH], DroppedItem droppedItems[], float playerX, float playerY, GameTextures &tex) {
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            int pixelX = x * TILE_SIZE;
            int pixelY = y * TILE_SIZE;

            if (worldMap[y][x] == DIRT) DrawTexture(tex.dirt, pixelX, pixelY, WHITE);
            else if (worldMap[y][x] == GRASS) DrawTexture(tex.grass, pixelX, pixelY, WHITE);
            else if (worldMap[y][x] == STONE) DrawTexture(tex.stone, pixelX, pixelY, WHITE);
            else if (worldMap[y][x] == BEDROCK) DrawTexture(tex.bedrock, pixelX, pixelY, WHITE);
            else if (worldMap[y][x] == WOOD) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, ORANGE);
        }
    }

    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        if (droppedItems[i].active) {
            int itemSize = 12;
            Color itemColor = WHITE;
            if (droppedItems[i].type == DIRT) itemColor = BROWN;
            else if (droppedItems[i].type == GRASS) itemColor = DARKGREEN;
            else if (droppedItems[i].type == STONE) itemColor = GRAY;
            else if (droppedItems[i].type == WOOD) itemColor = ORANGE;

            DrawRectangle(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, itemColor);
            DrawRectangleLines(droppedItems[i].position.x, droppedItems[i].position.y, itemSize, itemSize, BLACK);
        }
    }

    // Vẽ căn chỉnh nhân vật: Đưa kết cấu hình ảnh (32x32) bao bọc cân đối xung quanh hộp va chạm (22x32)
    int drawX = (int)(playerX - (32.0f - PLAYER_COLL_WIDTH) / 2.0f);
    int drawY = (int)playerY; 
    DrawTexture(tex.player, drawX, drawY, WHITE);
}

void DrawGameUI(bool isInventoryOpen, int activeSlot, InventorySlot inventory[], InventorySlot &heldItem, int screenWidth, int screenHeight, GameTextures &tex) {
    int slotSize = 40;
    int slotGap = 10;
    int hotbarWidth = (slotSize * 4) + (slotGap * 3);
    int hStartX = (screenWidth - hotbarWidth) / 2;
    int hStartY = screenHeight - slotSize - 20;

    for (int i = 0; i < 4; i++) {
        int slotX = hStartX + i * (slotSize + slotGap);
        DrawRectangle(slotX, hStartY, slotSize, slotSize, Fade(BLACK, 0.4f));

        if (i == activeSlot) DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 3, YELLOW);
        else DrawRectangleLinesEx((Rectangle){(float)slotX, (float)hStartY, (float)slotSize, (float)slotSize}, 1, WHITE);

        BlockType type = inventory[i].type;
        int count = inventory[i].count;

        if (type != AIR && count > 0) {
            if (type == DIRT) DrawTexture(tex.dirt, slotX + 4, hStartY + 4, WHITE);
            else if (type == GRASS) DrawTexture(tex.grass, slotX + 4, hStartY + 4, WHITE);
            else if (type == STONE) DrawTexture(tex.stone, slotX + 4, hStartY + 4, WHITE);
            
            DrawText(TextFormat("%d", count), slotX + slotSize - 15, hStartY + slotSize - 14, 10, WHITE);
        }
        char numStr[2] = {(char)('1' + i), '\0'};
        DrawText(numStr, slotX + 4, hStartY + 4, 12, LIGHTGRAY);
    }

    DrawText("Nut E: Dong/Mo UI | Phim 1->4: Chon o Hotbar | Chuot T/P: Dap/Dat", 10, 10, 16, WHITE);

    if (isInventoryOpen) {
        DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.6f));

        int invCols = 6, invRows = 2, invSlotSize = 44, invGap = 8;
        int invWidth = (invSlotSize * invCols) + (invGap * (invCols - 1));
        int invHeight = (invSlotSize * invRows) + (invGap * (invRows - 1));
        int invStartX = (screenWidth - invWidth) / 2;
        int invStartY = (screenHeight - invHeight) / 2;

        DrawRectangle(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, Fade(DARKGRAY, 0.9f));
        DrawRectangleLines(invStartX - 15, invStartY - 40, invWidth + 30, invHeight + 55, WHITE);
        DrawText("TUI DO (INVENTORY)", invStartX, invStartY - 30, 16, GOLD);

        for (int r = 0; r < invRows; r++) {
            for (int c = 0; c < invCols; c++) {
                int index = r * invCols + c;
                int slotX = invStartX + c * (invSlotSize + invGap);
                int slotY = invStartY + r * (invSlotSize + invGap);

                Vector2 mousePos = GetMousePosition();
                Rectangle slotRec = { (float)slotX, (float)slotY, (float)invSlotSize, (float)invSlotSize };

                DrawRectangle(slotX, slotY, invSlotSize, invSlotSize, BLACK);

                if (CheckCollisionPointRec(mousePos, slotRec)) {
                    DrawRectangleLinesEx(slotRec, 1, YELLOW);
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                        InventorySlot temp = inventory[index];
                        inventory[index] = heldItem;
                        heldItem = temp;
                    }
                } else {
                    DrawRectangleLines(slotX, slotY, invSlotSize, invSlotSize, GRAY);
                }

                if (inventory[index].type != AIR && inventory[index].count > 0) {
                    BlockType type = inventory[index].type;
                    int itemX = slotX + 6;
                    int itemY = slotY + 6;

                    if (type == DIRT) DrawTexture(tex.dirt, itemX, itemY, WHITE);
                    else if (type == GRASS) DrawTexture(tex.grass, itemX, itemY, WHITE);
                    else if (type == STONE) DrawTexture(tex.stone, itemX, itemY, WHITE);

                    DrawText(TextFormat("%d", inventory[index].count), slotX + invSlotSize - 18, slotY + invSlotSize - 14, 12, WHITE);
                }
            }
        }
    }

    if (isInventoryOpen && heldItem.type != AIR && heldItem.count > 0) {
        Vector2 mousePos = GetMousePosition();
        int itemX = mousePos.x - 16;
        int itemY = mousePos.y - 16;

        if (heldItem.type == DIRT) DrawTexture(tex.dirt, itemX, itemY, WHITE);
        else if (heldItem.type == GRASS) DrawTexture(tex.grass, itemX, itemY, WHITE);
        else if (heldItem.type == STONE) DrawTexture(tex.stone, itemX, itemY, WHITE);

        DrawText(TextFormat("%d", heldItem.count), itemX + 20, itemY + 20, 12, WHITE);
    }
}

// ============================================================================
// HÀM MAIN CHÍNH
// ============================================================================
int main() {
    const int screenWidth = 800;
    const int screenHeight = 450;
    InitWindow(screenWidth, screenHeight, "Raylib Sandbox 2D - Fixed Physics");

    GameTextures tex;
    tex.dirt = LoadTexture("asset/dirt.png"); 
    tex.grass = LoadTexture("asset/grass.png");
    tex.stone = LoadTexture("asset/stone.png");
    tex.bedrock = LoadTexture("asset/bedrock.png");
    tex.player = LoadTexture("asset/mainchar.png");
    tex.sun = LoadTexture("asset/sun.png");
    tex.cloud1 = LoadTexture("asset/cloud1.png");
    tex.cloud2 = LoadTexture("asset/cloud2.png");

    float playerX = 150.0f;
    float playerY = 100.0f;
    const float playerSpeed = 5.0f;
    float velocityY = 0.0f;
    const float gravity = 0.5f;
    const float jumpForce = -10.0f;
    bool isGrounded = false;

    int activeSlot = 0;
    bool isInventoryOpen = false;

    InventorySlot inventory[INVENTORY_SIZE];
    for (int i = 0; i < INVENTORY_SIZE; i++) {
        inventory[i].type = AIR;
        inventory[i].count = 0;
    }
    
    // Cho sẵn một ít block ban đầu vào túi đồ để test thử tính năng đặt block
    inventory[0] = (InventorySlot){ GRASS, 20 };
    inventory[1] = (InventorySlot){ DIRT, 20 };

    InventorySlot heldItem = { AIR, 0 };

    DroppedItem droppedItems[MAX_DROPPED_ITEMS];
    for (int i = 0; i < MAX_DROPPED_ITEMS; i++) {
        droppedItems[i].active = false;
    }

    Camera2D camera = { 0 };
    camera.offset = (Vector2){ screenWidth / 2.0f, screenHeight / 2.0f };
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;

    //Tạo thế giới và địa hình ngẫu nhiên
    int worldMap[MAP_HEIGHT][MAP_WIDTH];
        for (int x = 0; x < MAP_WIDTH; x++) {
        // Tính độ cao của mặt đất tại cột x
        int surfaceHeight = 15 + (int)(sinf(x * 0.1f) * 3.0f); 

            for (int y = 0; y < MAP_HEIGHT; y++) {
                if (y > surfaceHeight) {
                    // Lớp đá cứng nhất ở dưới đáy
                    if (y > surfaceHeight + 8) worldMap[y][x] = STONE;
                    // Lớp đất
                    else worldMap[y][x] = DIRT;
                } 
                else if (y == surfaceHeight) {
                    // Lớp bề mặt luôn là cỏ
                    worldMap[y][x] = GRASS;
                }
                else {
                    // Phần còn lại là không khí
                    worldMap[y][x] = AIR;
                }
                
                // Luôn giữ Bedrock ở dòng cuối cùng
                if (y == MAP_HEIGHT - 1) worldMap[y][x] = BEDROCK;
            }
        }

    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        
        if (IsKeyPressed(KEY_E)) isInventoryOpen = !isInventoryOpen;

        if (!isInventoryOpen) {
            if (IsKeyPressed(KEY_ONE))   activeSlot = 0;
            if (IsKeyPressed(KEY_TWO))   activeSlot = 1;
            if (IsKeyPressed(KEY_THREE)) activeSlot = 2;
            if (IsKeyPressed(KEY_FOUR))  activeSlot = 3;
        }

        UpdatePlayer(playerX, playerY, velocityY, isGrounded, playerSpeed, gravity, jumpForce, worldMap, isInventoryOpen);
        UpdateDroppedItems(droppedItems, playerX, playerY, inventory, gravity, worldMap);
        HandleMouseInteraction(worldMap, playerX, playerY, inventory, activeSlot, droppedItems, camera, isInventoryOpen);

        // Cập nhật camera bám theo trung tâm va chạm của nhân vật
        camera.target = (Vector2){ playerX + PLAYER_COLL_WIDTH / 2.0f, playerY + PLAYER_COLL_HEIGHT / 2.0f };
        if (camera.target.x < screenWidth / 2.0f) camera.target.x = screenWidth / 2.0f;
        if (camera.target.x > (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f) camera.target.x = (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f;
        if (camera.target.y < screenHeight / 2.0f) camera.target.y = screenHeight / 2.0f;
        if (camera.target.y > (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f) camera.target.y = (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f;

        BeginDrawing();
            ClearBackground(SKYBLUE);

            DrawTexture(tex.sun, screenWidth - 180, 50, WHITE);
            DrawTexture(tex.cloud1, 100, 60, WHITE);
            DrawTexture(tex.cloud2, 400, 100, WHITE);
            DrawTexture(tex.cloud1, 650, 130, WHITE);

            BeginMode2D(camera);
                DrawWorld(worldMap, droppedItems, playerX, playerY, tex);
            EndMode2D();

            DrawGameUI(isInventoryOpen, activeSlot, inventory, heldItem, screenWidth, screenHeight, tex);
        EndDrawing();
    }

    UnloadTexture(tex.dirt);
    UnloadTexture(tex.grass);
    UnloadTexture(tex.stone);
    UnloadTexture(tex.bedrock);
    UnloadTexture(tex.player);
    UnloadTexture(tex.sun);
    UnloadTexture(tex.cloud1);
    UnloadTexture(tex.cloud2);

    CloseWindow();
    return 0;
}