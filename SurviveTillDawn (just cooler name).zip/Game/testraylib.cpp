#include "raylib.h"

int main() {
    // 1. Khởi tạo cửa sổ game: Rộng 800px, Cao 450px, Tiêu đề cửa sổ
    const int screenWidth = 800;
    const int screenHeight = 450;
    InitWindow(screenWidth, screenHeight, "My First Raylib Sandbox");

    // Đặt số khung hình trên giây (FPS) là 60
    SetTargetFPS(60);

    // 2. Vòng lặp game chính (Game Loop)
    // Vòng lặp sẽ chạy liên tục cho đến khi bạn bấm nút X ở góc cửa sổ
    while (!WindowShouldClose()) {
        
        // --- BƯỚC CẬP NHẬT LOGIC GAME (UPDATE) SẼ VIẾT Ở ĐÂY ---


        // --- BƯỚC VẼ ĐỒ HỌA (DRAW) ---
        BeginDrawing();

            // Xóa màn hình cũ và tô bằng màu xám nhạt (RAYWHITE)
            ClearBackground(RAYWHITE);

            // Vẽ một dòng chữ thông báo lên màn hình tại tọa độ (x=190, y=200)
            // Cỡ chữ là 20, màu chữ là LIGHTGRAY (Xám nhạt)
            DrawText("Chuc mung! Ban da mo cua so Raylib thanh congg!", 190, 200, 20, LIGHTGRAY);

        EndDrawing();
    }

    // 3. Đóng cửa sổ và giải phóng bộ nhớ khi thoát game
    CloseWindow();

    return 0;
}