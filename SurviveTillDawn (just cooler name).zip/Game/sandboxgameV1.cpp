#include "raylib.h"

// 1. MỞ RỘNG BẢN ĐỒ (Rộng 60 ô ~ 1920 pixel để camera có chỗ cuộn)
const int MAP_WIDTH = 60;  
const int MAP_HEIGHT = 15; 
const int TILE_SIZE = 32;  


int main() {
    const int screenWidth = 800;
    const int screenHeight = 450;
    InitWindow(screenWidth, screenHeight, "Raylib Sandbox 2D - Physics & Camera");

    // Khởi tạo tọa độ Nhân vật
    float playerX = 100.0f;
    float playerY = 100.0f;
    const float playerSize = 30.0f; // Thu nhỏ nhân vật lại một chút cho đẹp với ô 32px
    const float playerSpeed = 5.0f;

    // --- BIẾN PHỤC VỤ TRỌNG LỰC & VẬT LÝ ---
    float velocityY = 0.0f;          // Vận tốc theo trục Y (rơi xuống)
    const float gravity = 0.5f;      // Sức hút trái đất (cộng dồn mỗi khung hình)
    const float jumpForce = -10.0f;  // Lực nhảy (âm vì trục Y hướng xuống, nhảy là đi lên)
    bool isGrounded = false;         // Kiểm tra nhân vật có đang đứng trên đất không

    // --- KHỞI TẠO CAMERA 2D ---
    Camera2D camera = { 0 };
    camera.offset = (Vector2){ screenWidth / 2.0f, screenHeight / 2.0f }; // Giữ nhân vật ở giữa màn hình
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;

    SetTargetFPS(60);

    // Khởi tạo Bản đồ
    int worldMap[MAP_HEIGHT][MAP_WIDTH];
    for (int y = 0; y < MAP_HEIGHT; y++) {        
        for (int x = 0; x < MAP_WIDTH; x++) {    
            if (y < 8) worldMap[y][x] = 0;  // Bầu trời
            else if (y == 8) worldMap[y][x] = 2; // Cỏ
            else worldMap[y][x] = 1;  // Đất
        }
    }

    // Vòng lặp game (Game Loop)
    while (!WindowShouldClose()) {
        
        // -------------------------------------------------------------
        // XỬ LÝ DI CHUYỂN NGANG & VA CHẠM TRỤC X
        // -------------------------------------------------------------
        float horizontalMove = 0.0f;
        if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) horizontalMove += playerSpeed;
        if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) horizontalMove -= playerSpeed;

        // Thử di chuyển nhân vật theo trục X
        playerX += horizontalMove;

        // Giữ nhân vật không vượt quá rìa trái/phải của THẾ GIỚI (Mép bản đồ 1920px)
        if (playerX < 0) playerX = 0;
        if (playerX > MAP_WIDTH * TILE_SIZE - playerSize) playerX = MAP_WIDTH * TILE_SIZE - playerSize;

        // KIỂM TRA VA CHẠM TRỤC X (Tránh đi xuyên tường)
        Rectangle playerRec = { playerX, playerY, playerSize, playerSize };
        for (int y = 0; y < MAP_HEIGHT; y++) {
            for (int x = 0; x < MAP_WIDTH; x++) {
                if (worldMap[y][x] != 0) { // Nếu là block cứng
                    Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                    if (CheckCollisionRecs(playerRec, tileRec)) {
                        if (horizontalMove > 0) playerX = tileRec.x - playerSize;    // Đẩy lùi lại bên trái tường
                        if (horizontalMove < 0) playerX = tileRec.x + TILE_SIZE;     // Đẩy lùi lại bên phải tường
                    }
                }
            }
        }


        // Nhấn Space để nhảy (Chỉ được nhảy khi đang đứng trên đất)
        if (IsKeyPressed(KEY_SPACE) && isGrounded) {
            velocityY = jumpForce;
            isGrounded = false;
        }

        // -------------------------------------------------------------
        // XỬ LÝ TRỌNG LỰC, NHẢY & VA CHẠM TRỤC Y
        // -------------------------------------------------------------
        velocityY += gravity; // Áp dụng trọng lực liên tục
        playerY += velocityY; // Thay đổi vị trí Y dựa trên vận tốc rơi

        // KIỂM TRA VA CHẠM TRỤC Y (Đứng trên đất hoặc đụng trần nhà)
        playerRec = { playerX, playerY, playerSize, playerSize };
        isGrounded = false; // Tạm thời coi như đang rơi rơi cho đến khi phát hiện chạm đất

        for (int y = 0; y < MAP_HEIGHT; y++) {
            for (int x = 0; x < MAP_WIDTH; x++) {
                if (worldMap[y][x] != 0) {
                    Rectangle tileRec = { (float)x * TILE_SIZE, (float)y * TILE_SIZE, TILE_SIZE, TILE_SIZE };
                    if (CheckCollisionRecs(playerRec, tileRec)) {
                        if (velocityY > 0) { // Đang rơi xuống và chạm đỉnh block
                            playerY = tileRec.y - playerSize; // Đặt nhân vật đứng ngay trên mặt block
                            velocityY = 0;
                            isGrounded = true; // Xác nhận đã chạm đất
                        }
                        else if (velocityY < 0) { // Đang nhảy lên và cụng đầu vào đáy block
                            playerY = tileRec.y + TILE_SIZE; // Đẩy nhân vật xuống dưới block
                            velocityY = 0;
                        }
                    }
                }
            }
        }

        // -------------------------------------------------------------
        // ĐIỀU CHỈNH & GIỚI HẠN CAMERA (CAMERA CLAMPING)
        // -------------------------------------------------------------
        // Để camera luôn hướng tiêu điểm vào tâm của nhân vật
        camera.target = (Vector2){ playerX + playerSize / 2.0f, playerY + playerSize / 2.0f };

        // GIỚI HẠN BIÊN CAMERA: Không cho camera cuộn ra ngoài rìa bản đồ
        // Giới hạn bên trái
        if (camera.target.x < screenWidth / 2.0f) camera.target.x = screenWidth / 2.0f;
        // Giới hạn bên phải
        if (camera.target.x > (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f) {
            camera.target.x = (MAP_WIDTH * TILE_SIZE) - screenWidth / 2.0f;
        }
        // Giới hạn bên trên và dưới
        if (camera.target.y < screenHeight / 2.0f) camera.target.y = screenHeight / 2.0f;
        if (camera.target.y > (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f) {
            camera.target.y = (MAP_HEIGHT * TILE_SIZE) - screenHeight / 2.0f;
        }

        // -------------------------------------------------------------
        // XỬ LÝ CHUỘT (CÓ CAMERA)
        // -------------------------------------------------------------
        // LƯU Ý: Khi màn hình cuộn, tọa độ chuột trên màn hình sẽ bị lệch so với thế giới thực.
        // Hàm GetScreenToWorld2D sẽ giúp đổi tọa độ chuột màn hình sang tọa độ thực trong Game.
        Vector2 mouseWorldPos = GetScreenToWorld2D(GetMousePosition(), camera);
        int mouseGridX = mouseWorldPos.x / TILE_SIZE;
        int mouseGridY = mouseWorldPos.y / TILE_SIZE;

        if (mouseGridX >= 0 && mouseGridX < MAP_WIDTH && mouseGridY >= 0 && mouseGridY < MAP_HEIGHT) {
            if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                worldMap[mouseGridY][mouseGridX] = 0; // Phá block
            }
            if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
                if (worldMap[mouseGridY][mouseGridX] == 0) worldMap[mouseGridY][mouseGridX] = 1; // Đặt đất
            }
        }

        // -------------------------------------------------------------
        // BƯỚC 2: VẼ ĐỒ HỌA (DRAW)
        // -------------------------------------------------------------
        BeginDrawing();
            ClearBackground(SKYBLUE);

            // BẮT ĐẦU CHẾ ĐỘ CAMERA 2D (Mọi thứ vẽ từ đây đến EndMode2D sẽ tự cuộn theo camera)
            BeginMode2D(camera);

                // Vẽ các ô bản đồ
                for (int y = 0; y < MAP_HEIGHT; y++) {
                    for (int x = 0; x < MAP_WIDTH; x++) {
                        int pixelX = x * TILE_SIZE;
                        int pixelY = y * TILE_SIZE;

                        if (worldMap[y][x] == 1) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, BROWN);
                        else if (worldMap[y][x] == 2) DrawRectangle(pixelX, pixelY, TILE_SIZE, TILE_SIZE, DARKGREEN);
                    }
                }

                // Vẽ nhân vật vuông màu đỏ
                DrawRectangle(playerX, playerY, playerSize, playerSize, RED);

            EndMode2D(); // KẾT THÚC CHẾ ĐỘ CAMERA

            // Phần chữ này vẽ NGOÀI camera nên nó sẽ đứng im trên màn hình làm UI
            DrawText("Di chuyen: A/D hoac Mui ten. Nhay: SPACE", 10, 10, 20, WHITE);
            DrawText("Chuot trai: Pha block | Chuot phai: Dat block", 10, 35, 20, WHITE);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}